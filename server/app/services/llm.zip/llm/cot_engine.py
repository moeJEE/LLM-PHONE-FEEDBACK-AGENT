import json
import os
import re
import asyncio
import backoff
from typing import Dict, Any, List, Optional, Union

from ...core.config import get_settings
from ...core.logging import get_logger

logger = get_logger("services.llm.cot_engine")
settings = get_settings()

class CoTEngine:
    """
    Chain-of-Thought Engine for working with LLMs to generate step-by-step reasoning
    and enhanced responses for the phone feedback system.
    """
    
    def __init__(self):
        """Initialize the CoT engine with appropriate LLM provider based on settings"""
        self.llm_provider = settings.LLM_PROVIDER.lower()
        
        if self.llm_provider == "openai":
            self._initialize_openai()
        elif self.llm_provider == "anthropic":
            self._initialize_anthropic()
        else:
            raise ValueError(f"Unsupported LLM provider: {self.llm_provider}")
    
    def _initialize_openai(self):
        """Initialize OpenAI client"""
        import openai
        
        openai.api_key = settings.OPENAI_API_KEY
        self.client = openai.Client()
        self.model = "gpt-4-turbo"  # Default model
    
    def _initialize_anthropic(self):
        """Initialize Anthropic client"""
        import anthropic
        
        self.client = anthropic.Anthropic(api_key=settings.ANTHROPIC_API_KEY)
        self.model = "claude-3-opus-20240229"  # Default model
    
    @backoff.on_exception(
        backoff.expo,
        Exception,
        max_tries=3,
        giveup=lambda e: "invalid" in str(e).lower()
    )
    async def generate(self, prompt: str, system_message: Optional[str] = None) -> str:
        """
        Generate a response without explicit CoT reasoning
        
        Args:
            prompt: The prompt to send to the LLM
            system_message: Optional system message to set context
            
        Returns:
            str: Generated response
        """
        try:
            if self.llm_provider == "openai":
                messages = []
                
                if system_message:
                    messages.append({"role": "system", "content": system_message})
                
                messages.append({"role": "user", "content": prompt})
                
                response = await asyncio.to_thread(
                    self.client.chat.completions.create,
                    model=self.model,
                    messages=messages,
                    temperature=0.7
                )
                
                return response.choices[0].message.content
            
            elif self.llm_provider == "anthropic":
                message_content = []
                
                if system_message:
                    message = self.client.messages.create(
                        model=self.model,
                        system=system_message,
                        messages=[{"role": "user", "content": prompt}],
                        temperature=0.7,
                        max_tokens=1024
                    )
                else:
                    message = self.client.messages.create(
                        model=self.model,
                        messages=[{"role": "user", "content": prompt}],
                        temperature=0.7,
                        max_tokens=1024
                    )
                
                return message.content[0].text
            
        except Exception as e:
            logger.error(f"Error generating LLM response: {str(e)}", exc_info=True)
            raise
    
    @backoff.on_exception(
        backoff.expo,
        Exception,
        max_tries=3,
        giveup=lambda e: "invalid" in str(e).lower()
    )
    async def generate_with_reasoning(self, prompt: str, system_message: Optional[str] = None) -> Dict[str, Any]:
        """
        Generate a response with explicit Chain-of-Thought reasoning
        
        Args:
            prompt: The prompt to send to the LLM
            system_message: Optional system message to set context
            
        Returns:
            Dict: Contains 'reasoning' (the step-by-step thought process) and 'output' (the final answer)
        """
        try:
            # Modify prompt to explicitly request CoT reasoning
            cot_prompt = f"""
{prompt}

Step through your reasoning in detail before providing your final answer. 
Think step-by-step through this problem:
1. First, analyze the context and question carefully
2. Break down the problem into parts if needed
3. Explore different perspectives or approaches
4. Draw a conclusion based on your reasoning

After your reasoning, provide your final output in a format that can be directly used, labeled as FINAL OUTPUT:
"""
            
            if self.llm_provider == "openai":
                messages = []
                
                if system_message:
                    messages.append({"role": "system", "content": system_message})
                
                messages.append({"role": "user", "content": cot_prompt})
                
                response = await asyncio.to_thread(
                    self.client.chat.completions.create,
                    model=self.model,
                    messages=messages,
                    temperature=0.7
                )
                
                full_response = response.choices[0].message.content
            
            elif self.llm_provider == "anthropic":
                if system_message:
                    message = self.client.messages.create(
                        model=self.model,
                        system=system_message,
                        messages=[{"role": "user", "content": cot_prompt}],
                        temperature=0.7,
                        max_tokens=2048
                    )
                else:
                    message = self.client.messages.create(
                        model=self.model,
                        messages=[{"role": "user", "content": cot_prompt}],
                        temperature=0.7,
                        max_tokens=2048
                    )
                
                full_response = message.content[0].text
            
            # Split reasoning from final output
            parts = re.split(r"FINAL OUTPUT:?", full_response, flags=re.IGNORECASE)
            
            if len(parts) >= 2:
                reasoning = parts[0].strip()
                output = parts[1].strip()
            else:
                # If the model didn't follow the format correctly
                reasoning = full_response
                output = full_response
            
            return {
                "reasoning": reasoning,
                "output": output
            }
            
        except Exception as e:
            logger.error(f"Error generating CoT response: {str(e)}", exc_info=True)
            raise
    
    async def generate_structured_output(
        self, 
        prompt: str, 
        output_schema: Dict[str, Any],
        system_message: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Generate a structured output (JSON) with Chain-of-Thought reasoning
        
        Args:
            prompt: The prompt to send to the LLM
            output_schema: JSON schema defining the expected output structure
            system_message: Optional system message to set context
            
        Returns:
            Dict: Structured output according to the provided schema
        """
        try:
            # Add instructions for structured output format
            schema_str = json.dumps(output_schema, indent=2)
            structured_prompt = f"""
{prompt}

Think through the problem step by step, and then provide your final answer as a valid JSON object with the following schema:
{schema_str}

Make sure your final JSON is properly formatted and can be parsed. Label it with FINAL_JSON: before the JSON object.
"""
            
            # Generate response with reasoning
            response = await self.generate_with_reasoning(structured_prompt, system_message)
            
            # Extract and parse JSON
            output = response.get("output", "")
            
            # Look for JSON pattern in the output
            json_pattern = r"```(?:json)?\s*([\s\S]*?)\s*```|FINAL_JSON:\s*([\s\S]*)"
            match = re.search(json_pattern, output)
            
            if match:
                json_str = match.group(1) or match.group(2)
                try:
                    result = json.loads(json_str.strip())
                    return result
                except json.JSONDecodeError as e:
                    logger.error(f"Invalid JSON in response: {json_str}", exc_info=True)
                    raise ValueError(f"Model generated invalid JSON: {str(e)}")
            else:
                # Try to parse the whole output as JSON
                try:
                    result = json.loads(output.strip())
                    return result
                except json.JSONDecodeError:
                    logger.error(f"Could not extract valid JSON from response: {output}")
                    raise ValueError("Model did not generate valid JSON output")
        
        except Exception as e:
            logger.error(f"Error generating structured output: {str(e)}", exc_info=True)
            raise